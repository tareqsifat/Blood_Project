
<?php $__env->startSection('content'); ?>
<div class="donor-search-area">
    <div class="container">
        <form method="GET" action="<?php echo e(route('donor.search')); ?>" class="donor-search-form">
            <div class="donor-search-form__field">
                <label><?php echo app('translator')->get('Blood Group'); ?></label>
                <select class="select" name="blood_id">
                    <option value="" selected="" disabled=""><?php echo app('translator')->get('Select Group'); ?></option>
                    <?php $__currentLoopData = $bloods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($blood->id); ?>" <?php if(@$bloodId == $blood->id): ?> selected <?php endif; ?>><?php echo e(__($blood->name)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="donor-search-form__field">
                <label><?php echo app('translator')->get('City'); ?></label>
                <select class="select" name="city_id">
                    <option value="" disabled="" selected=""><?php echo app('translator')->get('Select One'); ?></option>
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($city->id); ?>" data-locations="<?php echo e(json_encode($city->location)); ?>"><?php echo e(__($city->name)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="donor-search-form__field">
                <label><?php echo app('translator')->get('Location'); ?></label>
                <select class="select" name="location_id">
                    <option value="" selected="" disabled=""><?php echo app('translator')->get('Select One'); ?></option>
                </select>
            </div>

            <div class="donor-search-form__field">
                <label><?php echo app('translator')->get('Donor Type'); ?></label>
                <select class="select" name="gender">
                    <option value="" selected="" disabled=""><?php echo app('translator')->get('Select One'); ?></option>
                    <option value="1" <?php if(@$gender == 1): ?> selected <?php endif; ?>><?php echo app('translator')->get('Male'); ?></option>
                    <option value="2" <?php if(@$gender == 2): ?> selected <?php endif; ?>><?php echo app('translator')->get('Female'); ?></option>
                </select>
            </div>

            <div class="donor-search-form__btn">
                <button type="submit" class="btn btn-md btn--base"><?php echo app('translator')->get('Search'); ?></button>
            </div>
        </form>
    </div>
</div>

<section class="pt-50 pb-50 shade--bg">
    <div class="container">
        <div class="row">
            <div class="col-xl-2 col-lg-3 col-md-4 d-md-block d-none">
                <?php 
                    echo advertisements('220x474') 
                ?>

                <?php 
                    echo advertisements('220x303') 
                ?>

                <?php 
                    echo advertisements('220x474') 
                ?>

                <?php 
                    echo advertisements('220x474') 
                ?>
            </div>




            <div class="col-xl-8 col-lg-9 col-md-8">
                <div class="row gy-4">
                    <?php $__empty_1 = true; $__currentLoopData = $donors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-6 col-md-12 col-sm-6">
                            <div class="donor-item has--link">
                                <a href="<?php echo e(route('donor.details', [slug($donor->name), encrypt($donor->id)])); ?>" class="item--link"></a>
                                <div class="donor-item__thumb">
                                    	<?php if($donor->image == null): ?>

                    						<?php if($donor->gender == 1): ?> 
                    						<img src="<?php echo e(getImage('assets/images/donor/male.jpg')); ?>">
                    
                    						<?php else: ?> 
                    						<img src="<?php echo e(getImage('assets/images/donor/femail.jpg')); ?>">
                    
                    						<?php endif; ?>
                    
                    					<?php else: ?>
                    						
                    						<img src="<?php echo e(getImage('assets/images/donor/'. $donor->image, imagePath()['donor']['size'])); ?>" alt="<?php echo app('translator')->get('image'); ?>">
                    					<?php endif; ?>
                                    
                                </div>
                                <div class="donor-item__content">
                                    <h5 class="donor-item__name"><?php echo e(__($donor->name)); ?></h5>
                                    <ul class="donor-item__list mt-2">
                                        
                                        <li>
                                            <i class="las la-tint"></i><?php echo app('translator')->get('Blood Group'); ?> : <span class="text--base">(<?php echo e(__($donor->blood->name)); ?>)</span>
                                        </li>
                                        <li>
                                            <i class="las la-map-marker-alt"></i><?php echo app('translator')->get('City'); ?> : <span class="text--base">(<?php echo e(__($donor->city->name)); ?>)</span>
                                        </li>

                                        
                                    </ul>
                                    <a href="<?php echo e(route('donor.details', [slug($donor->name), encrypt($donor->id)])); ?>"  <button type="submit" class="btn btn-md btn--base"><?php echo app('translator')->get('Contact'); ?></button></a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h3 class="text-center">দুঃখিত, উক্ত লোকেশনে এখন পর্যন্ত কোনো রক্তদাতা নেই !</h3>
                    <?php endif; ?>
                </div>
                <nav class="mt-4 pagination-md">
                <?php echo e($donors->links()); ?>

                </nav>
            </div>
            <div class="col-xl-2 d-xl-block d-none">
                <?php 
                    echo advertisements('220x474') 
                ?>

                <?php 
                    echo advertisements('220x315') 
                ?>

                <?php 
                    echo advertisements('220x474') 
                ?>

                <?php 
                    echo advertisements('220x474') 
                ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    (function($){
        "use strict";

        $('select[name=city_id]').on('change',function() {
            $('select[name=location_id]').html('<option value="" selected="" disabled=""><?php echo app('translator')->get('Select One'); ?></option>');
            var locations = $('select[name=city_id] :selected').data('locations');
            var html = '';
            locations.forEach(function myFunction(item, index) {
                html += `<option value="${item.id}">${item.name}</option>`
            });
            $('select[name=location_id]').append(html);
        });
        
    })(jQuery)
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nayeemby430/public_html/core/resources/views/templates/basic/donor.blade.php ENDPATH**/ ?>
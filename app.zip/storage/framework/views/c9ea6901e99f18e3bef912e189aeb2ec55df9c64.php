<?php
    $faq = getContent('faq.content', true);
    $faqElements = getContent('faq.element', false);
?>

<section class="pt-100 pb-100">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section-header text-center">
                    <h2 class="section-title"><?php echo e(__(@$faq->data_values->heading)); ?></h2>
                    <p class="mt-3"><?php echo e(__(@$faq->data_values->sub_heading)); ?></p>
                </div>
            </div>
        </div><!-- row end -->
        <div class="accordion custom--accordion" id="faqAccordion">
            <div class="row">
                    <div class="col-lg-6 mb-4">
                        <?php $__currentLoopData = $faqElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faqElement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($loop->odd): ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="h-<?php echo e($loop->iteration); ?>">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c-<?php echo e($loop->iteration); ?>" aria-expanded="false" aria-controls="c-<?php echo e($loop->iteration); ?>">
                                        <?php echo e(__(@$faqElement->data_values->title)); ?>

                                    </button>
                                </h2>
                                <div id="c-<?php echo e($loop->iteration); ?>" class="accordion-collapse collapse" aria-labelledby="h-<?php echo e($loop->iteration); ?>" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        <p><?php echo e(__(@$faqElement->data_values->answer)); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                     <div class="col-lg-6 mb-4">
                        <?php $__currentLoopData = $faqElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faqElement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($loop->even): ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="h-<?php echo e($loop->iteration); ?>">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#c-<?php echo e($loop->iteration); ?>" aria-expanded="false" aria-controls="c-<?php echo e($loop->iteration); ?>">
                                        <?php echo e(__(@$faqElement->data_values->title)); ?>

                                    </button>
                                </h2>
                                <div id="c-<?php echo e($loop->iteration); ?>" class="accordion-collapse collapse" aria-labelledby="h-<?php echo e($loop->iteration); ?>" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        <p><?php echo e(__(@$faqElement->data_values->answer)); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/nayeemby430/public_html/core/resources/views/templates/basic/sections/faq.blade.php ENDPATH**/ ?>
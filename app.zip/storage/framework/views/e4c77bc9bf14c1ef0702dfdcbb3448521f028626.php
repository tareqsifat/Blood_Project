<?php
    $footer = getContent('footer.content', true);
    $contact = getContent('contact_us.content', true);
    $policys = getContent('policy_pages.element', false);
    $cookie = App\Models\Frontend::where('data_keys','cookie.data')->first();
?>

<?php if(!session('cookie_accepted')): ?>
    <div class="cookie__wrapper">
        <div class="container">
          <div class="d-flex flex-wrap align-items-center justify-content-between">
            <p class="txt my-2">
               <?php echo @$cookie->data_values->description ?>
              <a href="<?php echo e(@$cookie->data_values->link); ?>" target="_blank"><?php echo app('translator')->get('Read Policy'); ?></a>
            </p>
              <a href="javascript:void(0)" class="btn btn--base my-2 policy"><?php echo app('translator')->get('Accept'); ?></a>
          </div>
        </div>
    </div>
<?php endif; ?>

<footer class="footer img-overlay bg_img" style="background-image: url(<?php echo e(getImage('assets/images/frontend/footer/'. @$footer->data_values->background_image, '1920x921')); ?>);">
    <div class="footer__top">
        <div class="container">
            <div class="footer-info-area">
                <div class="row align-items-center gy-4">
                    <div class="col-lg-9">
                        <ul class="footer-contact-list justify-content-lg-start justify-content-center">
                            <li>
                                <div class="icon">
                                    <i class="las la-phone-volume"></i>
                                </div>
                                <div class="content">
                                    <a href="tel:<?php echo e(__($contact->data_values->contact_number)); ?>"><?php echo e(__($contact->data_values->contact_number)); ?></a>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="las la-envelope"></i>
                                </div>
                                <div class="content">
                                    <a href="mailto:<?php echo e(__($contact->data_values->email_address)); ?>"><?php echo e(__($contact->data_values->email_address)); ?></a>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="lab la-facebook"></i>
                                </div>
                                <div class="content">
                                    <a href="https://www.facebook.com/needbloodbangladesh">/needbloodbangladesh</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-3 text-lg-end text-center">
                        <a href="<?php echo e(url($footer->data_values->btn_url)); ?>" class="btn btn--base"><?php echo e(__($footer->data_values->btn_name)); ?></a>
                    </div>
                </div>
            </div>

            <div class="row gy-5 justify-content-between">
                <div class="col-xl-4 col-lg-4 col-sm-8 order-lg-1 order-1">
                    <div class="footer-widget">
                        <a href="<?php echo e(route('home')); ?>" class="footer-logo"><img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="<?php echo app('translator')->get('logo'); ?>"></a>
                        <p class="mt-3"><?php echo e(__($footer->data_values->title)); ?></p>
                        <form class="subscribe-form mt-4">
                            <input type="email" name="email" id="emailSub" class="form--control" placeholder="<?php echo app('translator')->get('Enter email address'); ?>">
                            <button type="button" class="subscribe-btn"><i class="lab la-telegram-plane"></i></button>
                        </form>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-3 col-sm-6 order-lg-2 order-3">
                    <div class="footer-widget">
                        <h4 class="footer-widget__title"><?php echo app('translator')->get('Short Links'); ?></h4>
                        <ul class="footer-links-list">
                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('pages',[$data->slug])); ?>"><?php echo e(__($data->name)); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-3 col-sm-6 order-lg-3 order-4">
                    <div class="footer-widget">
                        <h4 class="footer-widget__title"><?php echo app('translator')->get('Support'); ?></h4>
                        <ul class="footer-links-list">
                            <li><a href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Support Center'); ?></a></li>
                            <li><a href="<?php echo e(route('apply.donor')); ?>"><?php echo app('translator')->get('Apply as a Donor'); ?></a></li>
                            <?php $__currentLoopData = $policys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('footer.menu', [slug($policy->data_values->title), $policy->id])); ?>"><?php echo e(__($policy->data_values->title)); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-2 col-sm-4 order-lg-4 order-2">
                    <div class="footer-widget">
                        <ul class="footer-overview-list text-end">
                            <li class="footer-overview">
                                <h4 class="footer-overview__number"><?php echo e(__($footer->data_values->first_count_digits)); ?></h4>
                                <p class="footer-overview__caption"><?php echo e(__($footer->data_values->first_count_title)); ?></p>
                            </li>
                            <li class="footer-overview">
                                <h4 class="footer-overview__number"><?php echo e(__($footer->data_values->second_count_digits)); ?></h4>
                                <p class="footer-overview__caption"><?php echo e(__($footer->data_values->second_count_title)); ?></p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer__bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p><?php echo app('translator')->get('Copyright'); ?> © <?php echo e(Carbon\Carbon::now()->format('Y')); ?> <a href="<?php echo e(route('home')); ?>" class="text--base"> <?php echo e(__($general->sitename)); ?> </a> <?php echo app('translator')->get('All Right Reserved'); ?></p>
                </div>
            </div>
        </div>
    </div>
</footer>

<?php $__env->startPush('script'); ?>
<script>
    (function () {
        'use strict';
        $(document).on('click','.subscribe-btn' , function(){
            var email = $("#emailSub").val();
            if(email){
                $.ajax({
                    headers: {"X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>",},
                    url:"<?php echo e(route('subscribe')); ?>",
                    method:"POST",
                    data:{email:email},
                    success:function(response)
                    {
                        if(response.success) {
                            notify('success', response.success);
                            $("#emailSub").val('');
                        }else{
                            $.each(response, function (i, val) {
                                notify('error', val);
                            });
                        }
                    }
                });
            }
            else{
                notify('error', "Please Input Your Email");
            }
        });

        $('.policy').on('click',function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.get('<?php echo e(route('cookie.accept')); ?>', function(response){
                $('.cookie__wrapper').addClass('d-none');
                notify('success', response);
            });
        });
    })();
</script>
<?php $__env->stopPush(); ?><?php /**PATH /home/nayeemby430/public_html/core/resources/views/templates/basic/partials/footer.blade.php ENDPATH**/ ?>
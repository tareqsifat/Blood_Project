
<?php $__env->startSection('content'); ?>
<?php
    $breadcrumb = getContent('breadcrumb.content', true);
?>
<div class="profile-header dark--overlay bg_img" style="background-image: url(<?php echo e(getImage('assets/images/frontend/breadcrumb/'. @$breadcrumb->data_values->background_image, '1920x1440')); ?>);">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="donor-profile">
					<div class="donor-profile__thumb">
					    
					<?php if($donor->image == null): ?>

						<?php if($donor->gender == 1): ?> 
						<img src="<?php echo e(getImage('assets/images/donor/male.jpg')); ?>">

						<?php else: ?> 
						<img src="<?php echo e(getImage('assets/images/donor/femail.jpg')); ?>">

						<?php endif; ?>

					<?php else: ?>
						
						<img src="<?php echo e(getImage('assets/images/donor/'. $donor->image, imagePath()['donor']['size'])); ?>" alt="<?php echo app('translator')->get('image'); ?>">
					<?php endif; ?>
					
					</div>
					<div class="donor-profile__content">
						<h3 class="donor-profile__name"><?php echo e(__($donor->name)); ?></h3>
						<p><i class="las la-map-marker-alt mt-2"></i> <?php echo app('translator')->get('Location'); ?> : <?php echo e(__($donor->location->name)); ?>, <?php echo e(__($donor->city->name)); ?></p>
						<ul class="d-flex flex-wrap align-items-center donor-card__social justify-content-center mt-1">
                            <li><a href="<?php echo e(__(@$donor->socialMedia->facebook)); ?>" target="_blank" tabindex="-1"><i class="lab la-facebook-f"></i></a></li>
                            <li><a href="<?php echo e(__(@$donor->socialMedia->twitter)); ?>" target="_blank" tabindex="-1"><i class="lab la-twitter"></i></a></li>
                          <!--<li><a href="<?php echo e(__(@$donor->socialMedia->linkedinIn)); ?>" target="_blank" tabindex="-1"><i class="lab la-linkedin-in"></i></a></li>-->
                            <li><a href="<?php echo e(__(@$donor->socialMedia->instagram)); ?>" tabindex="-1"><i class="lab la-instagram"></i></a></li>
                        </ul>
					</div>
				</div>
			</div>
		</div>
		<div class="blood-donor-info-area">
			<div class="row justify-content-center">
				<div class="col-xl-3 col-lg-4">
					<div class="dono-info-item d-flex align-items-center justify-content-center">
						<h5 class="text-white me-3"><i class="las la-tint"></i> <?php echo app('translator')->get('Blood Group'); ?> : </h5>
						<p class="text--base"><?php echo e(__($donor->blood->name)); ?></p>
					</div>
				</div>
				<div class="col-xl-3 col-lg-4 mt-lg-0 mt-3">
					<div class="dono-info-item d-flex align-items-center justify-content-center">
						<h5 class="text-white me-3"><i class="las la-calendar-check"></i> <?php echo app('translator')->get('Last Donate'); ?> : </h5>
						<p class="text--base"><?php echo e(showDateTime($donor->last_donate, 'd M Y')); ?></p>
					</div>
				</div>
				<div class="col-xl-3 col-lg-4 mt-lg-0 mt-3">
					<div class="dono-info-item d-flex align-items-center justify-content-center">
						<h5 class="text-white me-3"><i class="las la-clipboard-list"></i> <?php echo app('translator')->get('Total Donate'); ?> : </h5>
						<p class="text--base"><?php echo e(__($donor->total_donate)); ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<section class="pt-100 pb-50 shade--bg">
	<div class="container">
		<div class="row gy-4">
			<div class="col-lg-8 pe-lg-5">
				<h3><?php echo app('translator')->get('Donor Details'); ?></h3>
				<p class="mt-2"><?php echo e(__($donor->details)); ?></p>
				<div class="mt-4">
					<?php 
	                    echo advertisements('820x213') 
	                ?>
				</div>
				<ul class="caption-list-two mt-4">
					<li>
						<span class="caption"><?php echo app('translator')->get('Name'); ?></span>
						<span class="value"><?php echo e(__($donor->name)); ?></span>
					</li>
					<li>
						<span class="caption"><?php echo app('translator')->get('Gender'); ?></span>
						<span class="value"><?php if($donor->gender == 1): ?> <?php echo app('translator')->get('Male'); ?> <?php else: ?> <?php echo app('translator')->get('Female'); ?> <?php endif; ?></span>
					</li>
					<!--<li>
						<span class="caption"><?php echo app('translator')->get('Date of Birth'); ?></span>
						<span class="value"><?php echo e(showDateTime($donor->birth_date, 'd M Y')); ?></span>
					</li>-->
					<li>
						<span class="caption"><?php echo app('translator')->get('Email'); ?></span>
						<span class="value"><?php echo e(__($donor->email)); ?></span>
					</li>
					<li>
						<span class="caption"><?php echo app('translator')->get('Phone'); ?></span>
						<span class="value"><?php echo e(__($donor->phone)); ?></span>
					</li>
					<li>
						<span class="caption"><?php echo app('translator')->get('Age'); ?></span>
						<span class="value"><?php echo e(Carbon\Carbon::parse($donor->birth_date)->age); ?> <?php echo app('translator')->get('Years'); ?></span>
					</li>
					<li>
						<span class="caption"><?php echo app('translator')->get('Address'); ?></span>
						<span class="value"><?php echo e(__($donor->location->name)); ?>, <?php echo e(__($donor->city->name)); ?></span>
					</li>
					<li>
						<span class="caption"><?php echo app('translator')->get('Religion'); ?></span>
						<span class="value"><?php echo e(__($donor->religion)); ?></span>
					</li>
					<li>
						<span class="caption"><?php echo app('translator')->get('Profession'); ?></span>
						<span class="value"><?php echo e(__($donor->profession)); ?></span>
					</li>


				</ul>

				<div class="mt-4">
					<?php 
	                    echo advertisements('820x213') 
	                ?>
				</div>
	         
			</div>
			<div class="col-lg-4">
				<div class="custom--card section--bg2">
					<div class="card-header">
						<h5 class="text-white"><?php echo app('translator')->get('Contact with Donor'); ?></h5>
					</div>
					<div class="card-body">
						<form method="POST" action="<?php echo e(route('donor.contact')); ?>" class="contact-donor-form">
							<?php echo csrf_field(); ?>
							<input type="hidden" name="donor_id" value="<?php echo e($donor->id); ?>">
							<div class="form-group">
								<input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form--control form-control-md" placeholder="<?php echo app('translator')->get('Enter name'); ?>" maxlength="80" required="">
							</div>
							<div class="form-group">
								<input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form--control form-control-md" placeholder="<?php echo app('translator')->get('Enter email'); ?>" maxlength="80" required="">
							</div>
							<div class="form-group">
								<textarea name="message" class="form--control" placeholder="<?php echo app('translator')->get('Message'); ?>" maxlength="500" required=""><?php echo e(old('message')); ?></textarea>
							</div>
							<button type="submit" class="btn btn--base w-100"><?php echo app('translator')->get('Message Now'); ?></button>
						</form>
					</div>
				</div>
				 <div class="mt-4">
				 	<?php 
	                    echo advertisements('416x554') 
	                ?>
				 </div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nayeemby430/public_html/core/resources/views/templates/basic/donor_details.blade.php ENDPATH**/ ?>
<?php
    $donor = getContent('donor.content', true);
    $donors = App\Models\Donor::where('status', 1)->orderBy('total_donate', 'DESC')->with('blood')->limit(4)->get();
?>

<section class="pt-100 pb-100 border-top  position-relative z-index-2 overflow-hidden">
    <div class="bottom-el-bg">
        <img src="<?php echo e(getImage('assets/images/frontend/donor/'. @$donor->data_values->background_image, '1920x596')); ?>" alt="<?php echo app('translator')->get('image'); ?>">
    </div>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section-header text-center">
                    <h2 class="section-title"><?php echo e(__(@$donor->data_values->heading)); ?></h2>
                    <p class="mt-2"><?php echo e(__($donor->data_values->sub_heading)); ?></p>
                </div>
            </div>
        </div>

        <div class="row justify-content-center gy-4">
            <?php $__currentLoopData = $donors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6">
                    <div class="donor-card style--two has--link section--bg2">
                        <a href="<?php echo e(route('donor.details', [slug($donor->name), encrypt($donor->id)])); ?>" class="item--link"></a>
                        <div class="donor-card__thumb">
                            <img src="<?php echo e(getImage('assets/images/donor/'. $donor->image, imagePath()['donor']['size'])); ?>" alt="<?php echo app('translator')->get('image'); ?>">
                        </div>
                        <div class="donor-card__content">
                            <h6 class="donor-card__name"><?php echo e(__($donor->name)); ?></h6>
                            <p class="fs--14px text-white"><?php echo app('translator')->get('Blood Group'); ?> : <span class="text--base">(<?php echo e(__($donor->blood->name)); ?>)</span></p>
                            <span class="donor-card__amount mt-1"><i class="las la-tint"></i> <?php echo e(__($donor->total_donate)); ?> <?php echo app('translator')->get('Times'); ?></span>
                            <a href="<?php echo e(route('donor.details', [slug($donor->name), encrypt($donor->id)])); ?>"  <button type="submit" class="btn btn-md btn--base"><?php echo app('translator')->get('View Profile'); ?></button></a>

                            
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
   <?php /**PATH /home/nayeemby430/public_html/core/resources/views/templates/basic/sections/donor.blade.php ENDPATH**/ ?>
<?php echo  loadTawkto() ?>
<?php echo  loadAnalytics() ?><?php /**PATH /home/nayeemby430/public_html/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>
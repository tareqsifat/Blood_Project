<?php
    $contact = getContent('contact_us.content', true);
?>
<style>
    .user-image {
        width: 40px; /* Set the desired width */
        height: 40px; /* Set the desired height */
        object-fit: cover; /* Maintain aspect ratio and crop if necessary */
    }
    .login-btn a {
            color: #ffffff !important
        
    }
    .login-btn a:hover{
            color: #ffffff !important
        }
</style>
<header class="header">
    <div class="header__top">
        <div class="container">
            <div class="row align-items-center gy-2">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <ul class="header__info-list d-flex flex-wrap align-items-center justify-content-sm-start justify-content-center">
                        <li><a href="tel:<?php echo e(__($contact->data_values->contact_number)); ?>"><i class="las la-phone"></i> <?php echo e(__($contact->data_values->contact_number)); ?></a></li>
                       <li><a href="mailto:<?php echo e(__($contact->data_values->email_address)); ?>"><i class="las la-envelope"></i> <?php echo e(__($contact->data_values->email_address)); ?></a></li>
                    </ul>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 text-sm-end text-center">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6"></div>
                            <div class="col-lg-6 col-md-6 col-sm-6" >
                                <select class="language-select langSel">
                                    <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->code); ?>" <?php if(session('lang') == $item->code): ?> selected  <?php endif; ?>><?php echo e(__($item->name)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="header__bottom">
        <div class="container">
            <nav class="navbar navbar-expand-xl p-0 align-items-center">
                <a class="site-logo site-title" href="<?php echo e(route('home')); ?>">
                    <img class="lazyload" data-src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="<?php echo app('translator')->get('logo'); ?>">
                </a>
                <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="menu-toggle"></span>
                </button>
                <div class="collapse navbar-collapse mt-lg-0 mt-3" id="navbarSupportedContent">
                    <ul class="navbar-nav main-menu ms-auto">
                        <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                         <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('pages',[$data->slug])); ?>"><?php echo e(__($data->name)); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="nav-right">
                        <a href="<?php echo e(route('apply.donor')); ?>" class="btn btn-md btn--base d-flex align-items-center"><i class="las la-user fs--18px me-2"></i> <?php echo app('translator')->get('Apply as a Donor'); ?></a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
</header>
<?php /**PATH /var/www/html/BloodMessage/core/resources/views/templates/basic/partials/header.blade.php ENDPATH**/ ?>
<?php echo  loadTawkto() ?>
<?php echo  loadAnalytics() ?><?php /**PATH /var/www/html/BloodMessage/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>
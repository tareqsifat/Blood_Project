<?php
    $howIt = getContent('how_it_work.content', true);
    $howItElements = getContent('how_it_work.element', false);
?>

<section class="pt-80 pb-80 dark--overlay bg_img" style="background-image: url('<?php echo e(getImage('assets/images/frontend/how_it_work/'. @$howIt->data_values->background_image, '1920x1440')); ?>');">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="section-header text-center">
                    <h2 class="section-title text-white"><?php echo e(__(@$howIt->data_values->heading)); ?></h2>
                </div>
            </div>
        </div>
        <div class="row gy-5">
            <?php $__currentLoopData = $howItElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $howItElement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-sm-6 work-card">
                    <div class="work-item">
                        <div class="work-item__icon">
                            <span class="step"><?php echo e($loop->iteration); ?></span>
                            <?php echo $howItElement->data_values->icon ?>
                        </div>
                        <h5 class="work-item__title text-white"><?php echo e(__($howItElement->data_values->title)); ?></h5>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH /var/www/html/BloodMessage/core/resources/views/templates/basic/sections/how_it_work.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make($activeTemplate . 'partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="pt-100 pb-100 position-relative z-index section--bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <form method="POST" action="<?php echo e(route('apply.donor.store')); ?>" class="contact-form bg-white p-sm-5 p-3 rounded-3 position-relative" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <h5 class="mb-3"><?php echo app('translator')->get('Personal Information'); ?></h5>
                    <div class="row mb-4">
                        <div class="form-group col-lg-6">
                            <label for="name"><?php echo app('translator')->get('Name'); ?> <sup class="text--danger">*</sup></label>
                            <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo app('translator')->get('Full name'); ?>" class="form--control" maxlength="80" required="">
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="email"><?php echo app('translator')->get('Email'); ?> <sup class="text--danger">*</sup></label>
                            <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo app('translator')->get('Enter Email'); ?>" class="form--control" maxlength="60" required="">
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="phone"><?php echo app('translator')->get('Phone'); ?> <sup class="text--danger">*</sup></label>
                            <input type="text" name="phone" id="phone" value="<?php echo e(old('phone')); ?>" placeholder="<?php echo app('translator')->get('Enter Phone'); ?>" class="form--control" maxlength="40" required="">
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="city"><?php echo app('translator')->get('City'); ?> <sup class="text--danger">*</sup></label>
                            <select name="city" id="city" class="select" required="">
                                <option value="" selected="" disabled=""><?php echo app('translator')->get('Select One'); ?></option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->id); ?>" data-locations="<?php echo e(json_encode($city->location)); ?>"><?php echo e(__($city->name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="location"><?php echo app('translator')->get('Location'); ?> <sup class="text--danger">*</sup></label>
                            <select name="location" id="location" class="select" required="">
                                <option value="" selected="" disabled=""><?php echo app('translator')->get('Select One'); ?></option>
                            </select>
                        </div>
                        <!--<div class="form-group col-lg-6">-->
                        <!--    <label for="address"><?php echo app('translator')->get('Address'); ?> <sup class="text--danger">*</sup></label>-->
                        <!--    <input type="text" name="address" id="address" value="<?php echo e(old('address')); ?>" placeholder="<?php echo app('translator')->get('Enter Address'); ?>" class="form--control" maxlength="255" required="">-->
                        <!--</div>-->
                         <div class="form-group col-lg-6">
                            <label for="file"><?php echo app('translator')->get('Image'); ?> <sup class="text--danger"></sup></label>
                            <input type="file" id="file" name="image" class="form--control custom-file-upload">
                        </div>

                    </div>


                    <div class="row mb-4">
                        <h5 class="mb-3"><?php echo app('translator')->get('Socail Links'); ?></h5>
                        <div class="form-group col-lg-3 col-sm-6">
                            <label for="facebook"><?php echo app('translator')->get('Facebook Url'); ?> <sup class="text--danger">*</sup></label>
                            <div class="custom-icon-field">
                                <i class="lab la-facebook-f"></i>
                                <input type="text" name="facebook" id="facebook" value="https://www.facebook.com/" placeholder="<?php echo app('translator')->get('https://www.facebook.com/'); ?>" class="form--control" required="">
                            </div>
                        </div>
                        <div class="form-group col-lg-3 col-sm-6">
                            <label for="twitter"><?php echo app('translator')->get('Twitter Url'); ?> </label>
                            <div class="custom-icon-field">
                                <i class="lab la-twitter"></i>
                                <input type="text" name="twitter" id="twitter" value="https://www.twitter.com/" placeholder="<?php echo app('translator')->get('https://www.twitter.com/'); ?>" class="form--control">
                            </div>
                        </div>
                        <!--<div class="form-group col-lg-3 col-sm-6">-->
                        <!--    <label for="linkedinIn"><?php echo app('translator')->get('Linkedin Url'); ?> </label>-->
                        <!--    <div class="custom-icon-field">-->
                        <!--        <i class="lab la-linkedin-in"></i>-->
                        <!--        <input type="text" name="linkedinIn" id="linkedinIn" value="<?php echo e(old('linkedinIn')); ?>" placeholder="<?php echo app('translator')->get('https://www.linkdin.com/'); ?>" class="form--control" >-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="form-group col-lg-3 col-sm-6">
                            <label for="instagram"><?php echo app('translator')->get('Instagram Url'); ?> </label>
                            <div class="custom-icon-field">
                                <i class="lab la-instagram"></i>
                                <input type="text" name="instagram" id="instagram" value="https://www.instagram.com/" placeholder="<?php echo app('translator')->get('https://www.instagram.com/'); ?>" class="form--control" >
                            </div>
                        </div>
                    </div> 


                    <div class="row">
                        <h5 class="mb-3"><?php echo app('translator')->get('Others Information'); ?></h5>
                        <div class="form-group col-lg-6">
                            <label for="blood_id"><?php echo app('translator')->get('Blood Group'); ?> <sup class="text--danger">*</sup></label>
                            <select name="blood" id="blood_id" class="select" required="">
                               <option value="" selected="" disabled=""><?php echo app('translator')->get('Select One'); ?></option>
                               <?php $__currentLoopData = $bloods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($blood->id); ?>"><?php echo e(__($blood->name)); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="gender"><?php echo app('translator')->get('Gender'); ?> <sup class="text--danger">*</sup></label>
                            <select name="gender" id="gender" class="select" required="">
                                <option value="" selected="" disabled=""><?php echo app('translator')->get('Select One'); ?></option>
                                <option value="1"><?php echo app('translator')->get('Male'); ?></option>
                                <option value="2"><?php echo app('translator')->get('Female'); ?></option>
                            </select>
                        </div>

                        <!--<div class="form-group col-lg-6">-->
                        <!--    <label for="religion"><?php echo app('translator')->get('Religion'); ?> <sup class="text--danger">*</sup></label>-->
                        <!--    <input type="text" name="religion" id="religion" value="<?php echo e(old('religion')); ?>" placeholder="<?php echo app('translator')->get('Enter Religion'); ?>" class="form--control" maxlength="40" required="">-->
                        <!--</div>-->

                        <!-- <div class="form-group col-lg-6">-->
                        <!--    <label for="profession"><?php echo app('translator')->get('Profession'); ?> </label>-->
                        <!--    <input type="text" name="profession" id="profession" value="<?php echo e(old('profession')); ?>" placeholder="<?php echo app('translator')->get('Enter profession'); ?>" class="form--control" maxlength="80">-->
                        <!--</div>-->

                         <div class="form-group col-lg-6">
                            <label for="donate"><?php echo app('translator')->get('Total Donate'); ?> <sup class="text--danger"></sup></label>
                            <input type="number" name="donate" id="donate" value="0" placeholder="<?php echo app('translator')->get('Enter total blood donate'); ?>" class="form--control">
                        </div>

                       
                        <!--<div class="form-group col-lg-6">-->
                        <!--    <label for="date_birth"><?php echo app('translator')->get('Date Of Birth'); ?> <sup class="text--danger">*</sup></label>-->
                        <!--    <input type="text" id="date_birth" name="birth_date" value="<?php echo e(old('birth_date')); ?>" data-language="en" placeholder="<?php echo app('translator')->get('2000-01-30'); ?>" class="form--control datepicker-here" maxlength="255" required="">-->
                        <!--</div>-->

                         <div class="form-group col-lg-6">
                            <label for="last_donate"><?php echo app('translator')->get('Last Donate'); ?> </label>
                            <input type="text" name="last_donate" id="last_donate" value="<?php echo e(old('donate')); ?>" data-language="en" placeholder="<?php echo app('translator')->get('Enter Date'); ?>" class="form--control datepicker-here">
                        </div>

                        <!--<div class="form-group col-lg-12">-->
                        <!--    <label for="about_details"><?php echo app('translator')->get('About You'); ?> </label>-->
                        <!--    <textarea name="details" id="about_details" placeholder="<?php echo app('translator')->get('Enter Details'); ?>" class="form--control"><?php echo e(old('details')); ?></textarea>-->
                        <!--</div>-->
                        
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" name="checkbox" id="flexCheckDefault myCheck" required >
                          <label class="form-check-label" for="flexCheckDefault">
                            <?php echo app('translator')->get('Needbloodbd.com is not responsible if someone, unfortunately, harasses me using my personal information.'); ?>
                          </label>
                        </div>
                        <div class="col-lg-12">
                            <button type="submit" class="btn btn--base w-100"><?php echo app('translator')->get('Apply Now'); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<script>
function myFunction() {
  var x = document.getElementById("myCheck").required;
  document.getElementById("demo").innerHTML = x;
}
</script>

<?php echo $__env->make($activeTemplate.'sections.faq', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('style-lib'); ?>
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue.'frontend/css/datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset($activeTemplateTrue.'frontend/js/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset($activeTemplateTrue.'frontend/js/datepicker.en.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
  <script>
    (function($){
        "use strict";
        $('.datepicker-here').datepicker({
            autoClose: true,
            dateFormat: 'yyyy-mm-dd',
        });

        $('select[name=city]').on('change',function() {
            $('select[name=location]').html('<option value="" selected="" disabled=""><?php echo app('translator')->get('Select One'); ?></option>');
            var locations = $('select[name=city] :selected').data('locations');
            var html = '';
            locations.forEach(function myFunction(item, index) {
                html += `<option value="${item.id}">${item.name}</option>`
            });
            $('select[name=location]').append(html);
        });
    })(jQuery)
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/BloodMessage/core/resources/views/templates/basic/apply_donor.blade.php ENDPATH**/ ?>
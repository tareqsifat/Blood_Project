<?php
    $patner = getContent('patner.content', true);
    $patnerElements = getContent('patner.element', false);
?>

<section class="pt-100 pb-100 shade--bg2 overflow-hidden">
    <div class="container border-bottom">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="section-header text-center">
                    <h2 class="section-title"><?php echo e(__(@$patner->data_values->heading)); ?></h2>
                    <p><?php echo e(__(@$patner->data_values->sub_heading)); ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-5">
        <div class="brand-slider">
            <?php $__currentLoopData = $patnerElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patnerElement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single-slide">
                    <div class="partner-item">
                        <img class="lazyload" data-src="<?php echo e(getImage('assets/images/frontend/patner/'. @$patnerElement->data_values->background_image, '255x241')); ?>" alt="<?php echo app('translator')->get('image'); ?>">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<?php /**PATH /var/www/html/BloodMessage/core/resources/views/templates/basic/sections/patner.blade.php ENDPATH**/ ?>

<?php
    $about = getContent('about.content', true);
    $aboutElement = getContent('about.element', false);
?>

<section class="pt-100 pb-100 shade--bg">
    <div class="container">
        <div class="row gy-5">
            <div class="col-lg-6">
                <div class="about-thumb">
                    <a class="play-btn" href="<?php echo e(__(@$about->data_values->video_link)); ?>" data-rel="lightcase:myCollection"><i class="las la-play"></i></a>
                    <img class="w-100 h-100 lazyload" data-src="<?php echo e(getImage('assets/images/frontend/about/'. @$about->data_values->about_image, '992x661')); ?>" alt="<?php echo app('translator')->get('image'); ?>">
                </div>
            </div>

            <div class="col-lg-6 ps-lg-5">
                <div class="section-header mb-5 text-sm-start text-center">
                    <h2 class="section-title"><?php echo e(__(@$about->data_values->heading)); ?></h2>
                    <p><?php echo e(__(@$about->data_values->sub_heading)); ?></p>
                </div>
                <div class="row gy-4">
                    <?php $__currentLoopData = $aboutElement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-12">
                            <div class="about-item">
                                <div class="about-item__icon">
                                    <?php echo $value->data_values->about_icon ?>
                                </div>
                                <div class="about-item__content">
                                    <h4 class="about-item__title"><?php echo e(__($value->data_values->title)); ?></h4>
                                    <p><?php echo e(__($value->data_values->sub_title)); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/html/BloodMessage/core/resources/views/templates/basic/sections/about.blade.php ENDPATH**/ ?>
<?php $__env->startSection('panel'); ?>
<form action="<?php echo e(route('donor_login.donor_update')); ?>" method="POST" class="cmn-form mt-30 donor_auth_otp_verify">
    <?php echo csrf_field(); ?>
    <div class="container">
        <div class="row">
            <div class="col-6">
                <div class="form-group">
                    <label for="name"><?php echo app('translator')->get('Enter name'); ?></label>
                    <input type="text" name="name" class="form-control b-radius--capsule auth_otp_number" id="name" value="<?php echo e(old('name', $user->name)); ?>" placeholder="<?php echo app('translator')->get('Enter name'); ?>">
                </div>
                <div class="form-group">
                    <label for="email"><?php echo app('translator')->get('Email'); ?></label>
                    <input type="text" name="email" class="form-control b-radius--capsule" id="email" value="<?php echo e(old('email', $user->email)); ?>" placeholder="<?php echo app('translator')->get('Email'); ?>">
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label for="mobile_number"><?php echo app('translator')->get('Enter Mobile Number'); ?></label>
                    <input type="text" name="mobile_number" class="form-control b-radius--capsule auth_otp_number" id="mobile_number" value="<?php echo e(old('mobile_number', $user->phone)); ?>" placeholder="<?php echo app('translator')->get('Enter Mobile Number'); ?>">
                </div>
                <div class="form-group">
                    <label for="district"><?php echo app('translator')->get("District"); ?></label>
                    <select name="district" class="form-control b-radius--capsule" id="district">
                        
                        <option value="">--select--</option>
                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($city->id); ?>" <?php if($user->city_id == $city->id): ?> selected <?php endif; ?>><?php echo e(__($city->name)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group">
        <button type="submit" class="submit-btn mt-25 b-radius--capsule"><?php echo app('translator')->get('Login'); ?> <i class="las la-sign-in-alt"></i></button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('donor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/BloodMessage/core/resources/views/donor/dashboard/dashboard.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<?php
    $banner = getContent('banner.content', true);
?>

<section class="hero bg_img" style="background-image: url(<?php echo e(getImage('assets/images/frontend/banner/'. @$banner->data_values->background_image, '1920x1280')); ?>);">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xxl-6 col-xl-7 col-lg-8 text-center">
                <h2 class="hero__title"><?php echo e(__(@$banner->data_values->heading)); ?></h2>
            </div>
        </div>
        <div class="row justify-content-center mt-4">
            <div class="col-xxl-7 col-xl-8 col-lg-10">
                <form method="GET" action="<?php echo e(route('donor.search')); ?>" class="hero__blood-search-form">
                    <div class="input-field">
                        <i class="las la-tint"></i>
                        <select name="blood_id">
                            <option value="" selected="" disabled=""><?php echo app('translator')->get('Select Blood Group'); ?></option>
                            <?php $__currentLoopData = $bloods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e(__($blood->id)); ?>"><?php echo e(__($blood->name)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="input-field">
                        <i class="las la-city"></i>
                        <select name="city_id">
                            <option value="" selected="" disabled=""><?php echo app('translator')->get('Select City'); ?></option>
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e(__($city->id)); ?>"><?php echo e(__($city->name)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="btn-area">
                        <button type="submit" class="btn btn-md btn--base"><i class="las la-search"></i> <?php echo app('translator')->get('Search'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php if($sections->secs != null): ?>
    <?php $__currentLoopData = json_decode($sections->secs); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make($activeTemplate.'sections.'.$sec, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/BloodMessage/core/resources/views/templates/basic/home.blade.php ENDPATH**/ ?>